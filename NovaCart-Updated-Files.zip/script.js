// IMPORTANT: Add your WhatsApp number in international format, without + or spaces.
// Example format for a Nigerian number: 2348012345678
const WHATSAPP_NUMBER = "2349165471932";

const toast = document.getElementById("toast");
let toastTimer;
function showToast(message) {
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 3200);
}
function contactWhatsApp(product = "") {
  if (!WHATSAPP_NUMBER || !/^\d{10,15}$/.test(WHATSAPP_NUMBER)) {
    showToast("Store setup needed: add your WhatsApp number in script.js first.");
    return;
  }
  const message = product
    ? `Hello NovaCart, please confirm availability, total price and delivery for: ${product}.`
    : "Hello NovaCart, I'd like to ask about your products.";
  window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`, "_blank", "noopener");
}
document.querySelectorAll(".order-button").forEach(button => {
  button.addEventListener("click", () => contactWhatsApp(button.dataset.product));
});
document.getElementById("contactButton").addEventListener("click", () => contactWhatsApp());
document.querySelectorAll(".filter").forEach(button => {
  button.addEventListener("click", () => {
    document.querySelectorAll(".filter").forEach(item => item.classList.remove("active"));
    button.classList.add("active");
    const filter = button.dataset.filter;
    document.querySelectorAll(".product-card").forEach(card => {
      card.hidden = filter !== "all" && card.dataset.category !== filter;
    });
  });
});
document.getElementById("year").textContent = new Date().getFullYear();
